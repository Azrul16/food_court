import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import '../models/dish.dart';

class DishCard extends StatefulWidget {
  final Dish dish;
  const DishCard({required this.dish});

  @override
  _DishCardState createState() => _DishCardState();
}

class _DishCardState extends State<DishCard> with SingleTickerProviderStateMixin {
  bool _isFavorite = false;
  final User? user = FirebaseAuth.instance.currentUser;
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _loadFavoriteStatus();
    _animationController = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 300),
      lowerBound: 0.7,
      upperBound: 1.0,
    );
    _scaleAnimation = CurvedAnimation(parent: _animationController, curve: Curves.easeInOut);
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _loadFavoriteStatus() async {
    if (user == null) return;
    final doc = await FirebaseFirestore.instance
        .collection('user_favorites')
        .doc(user!.uid)
        .collection('dishes')
        .doc(widget.dish.id)
        .get();
    setState(() {
      _isFavorite = doc.exists;
    });
  }

  Future<void> _toggleFavorite() async {
    if (user == null) return;
    final favRef = FirebaseFirestore.instance
        .collection('user_favorites')
        .doc(user!.uid)
        .collection('dishes')
        .doc(widget.dish.id);

    if (_isFavorite) {
      await favRef.delete();
      _animationController.reverse();
    } else {
      await favRef.set({
        'title': widget.dish.title,
        'image': widget.dish.image,
        'price': widget.dish.price,
        'timestamp': FieldValue.serverTimestamp(),
      });
      _animationController.forward();
    }
    setState(() {
      _isFavorite = !_isFavorite;
    });
  }

  void _orderFood(BuildContext context) {
    final _quantityController = TextEditingController(text: '1');
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Order ${widget.dish.title}'),
        content: TextField(
          controller: _quantityController,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(labelText: 'Quantity'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              final quantity = int.tryParse(_quantityController.text) ?? 1;
              final userId = user?.uid ?? 'dummy_user';
              try {
                await FirebaseFirestore.instance.collection('orders').add({
                  'userId': userId,
                  'foodId': widget.dish.id,
                  'quantity': quantity,
                  'status': 'pending',
                  'timestamp': FieldValue.serverTimestamp(),
                });
                Navigator.of(ctx).pop();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Order placed successfully')),
                );
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Failed to place order')),
                );
              }
            },
            child: Text('Order'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ScaleTransition(
      scale: _scaleAnimation,
      child: Container(
        margin: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: Colors.grey[900],
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black54,
              blurRadius: 8,
              offset: Offset(0, 4),
            ),
          ],
        ),
        child: ListTile(
          leading: ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.network(
              widget.dish.image,
              width: 60,
              height: 60,
              fit: BoxFit.cover,
            ),
          ),
          title: Text(
            widget.dish.title,
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Colors.white),
          ),
          subtitle: Text(widget.dish.slogan, style: TextStyle(color: Colors.grey[400])),
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('\$${widget.dish.price.toStringAsFixed(2)}', style: TextStyle(fontSize: 16, color: Colors.white)),
              SizedBox(width: 8),
              IconButton(
                icon: Icon(
                  _isFavorite ? Icons.favorite : Icons.favorite_border,
                  color: _isFavorite ? Colors.redAccent : Colors.white,
                  size: 28,
                ),
                onPressed: _toggleFavorite,
              ),
              ElevatedButton(
                onPressed: () => _orderFood(context),
                child: Text('Order'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
