import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'app.dart';

void main() {
  runApp(OnlineFoodOrderingApp());
}


// Dummy data models

class Restaurant {
  final int id;
  final String title;
  final String address;
  final String image;

  Restaurant({
    required this.id,
    required this.title,
    required this.address,
    required this.image,
  });
}

class Dish {
  final int id;
  final int restaurantId;
  final String title;
  final String slogan;
  final double price;
  final String image;

  Dish({
    required this.id,
    required this.restaurantId,
    required this.title,
    required this.slogan,
    required this.price,
    required this.image,
  });
}

// Dummy data

final List<Restaurant> dummyRestaurants = [
  Restaurant(
    id: 1,
    title: 'North Street Tavern',
    address: '1128 North St, White Plains',
    image: 'https://via.placeholder.com/150',
  ),
  Restaurant(
    id: 2,
    title: 'Eataly',
    address: '800 Boylston St, Boston',
    image: 'https://via.placeholder.com/150',
  ),
  Restaurant(
    id: 3,
    title: 'Nan Xiang Xiao Long Bao',
    address: 'Queens, New York',
    image: 'https://via.placeholder.com/150',
  ),
];

final List<Dish> dummyDishes = [
  Dish(
    id: 1,
    restaurantId: 1,
    title: 'Yorkshire Lamb Patties',
    slogan: 'Lamb patties which melt in your mouth, and are quick and easy to make.',
    price: 14.00,
    image: 'https://via.placeholder.com/150',
  ),
  Dish(
    id: 2,
    restaurantId: 1,
    title: 'Lobster Thermidor',
    slogan: 'Lobster Thermidor is a French dish of lobster meat cooked in a rich wine sauce.',
    price: 36.00,
    image: 'https://via.placeholder.com/150',
  ),
  Dish(
    id: 3,
    restaurantId: 2,
    title: 'Chicken Madeira',
    slogan: 'Chicken Madeira, like Chicken Marsala, is made with chicken, mushrooms, and a special fortified wine.',
    price: 23.00,
    image: 'https://via.placeholder.com/150',
  ),
];

// Home Screen with featured restaurants and popular dishes

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Online Food Ordering'),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SectionTitle(title: 'Featured Restaurants'),
            SizedBox(
              height: 200,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: dummyRestaurants.length,
                itemBuilder: (context, index) {
                  final restaurant = dummyRestaurants[index];
                  return RestaurantCard(restaurant: restaurant);
                },
              ),
            ),
            SectionTitle(title: 'Popular Dishes'),
            ListView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: dummyDishes.length,
              itemBuilder: (context, index) {
                final dish = dummyDishes[index];
                return DishCard(dish: dish);
              },
            ),
          ],
        ),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String title;
  const SectionTitle({required this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Text(
        title,
        style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
      ),
    );
  }
}

class RestaurantCard extends StatelessWidget {
  final Restaurant restaurant;
  const RestaurantCard({required this.restaurant});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 160,
      margin: EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 100,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
              image: DecorationImage(
                image: NetworkImage(restaurant.image),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              restaurant.title,
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: Text(
              restaurant.address,
              style: TextStyle(fontSize: 12, color: Colors.grey[400]),
            ),
          ),
        ],
      ),
    );
  }
}

class DishCard extends StatelessWidget {
  final Dish dish;
  const DishCard({required this.dish});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.grey[900],
        borderRadius: BorderRadius.circular(12),
      ),
      child: ListTile(
        leading: Image.network(
          dish.image,
          width: 60,
          height: 60,
          fit: BoxFit.cover,
        ),
        title: Text(
          dish.title,
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(dish.slogan),
        trailing: Text('\$${dish.price.toStringAsFixed(2)}'),
      ),
    );
  }
}

// Orders Screen with dummy orders

class OrdersScreen extends StatelessWidget {
  final List<String> dummyOrders = [
    'Order #1 - Yorkshire Lamb Patties',
    'Order #2 - Lobster Thermidor',
    'Order #3 - Chicken Madeira',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My Orders'),
      ),
      body: ListView.builder(
        itemCount: dummyOrders.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(dummyOrders[index]),
            leading: Icon(Icons.receipt),
          );
        },
      ),
    );
  }
}

// Profile Screen with dummy user info

class ProfileScreen extends StatelessWidget {
  final String dummyUsername = 'john_doe';
  final String dummyEmail = 'john@example.com';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Username: $dummyUsername', style: TextStyle(fontSize: 18)),
            SizedBox(height: 8),
            Text('Email: $dummyEmail', style: TextStyle(fontSize: 18)),
          ],
        ),
      ),
    );
  }
}
