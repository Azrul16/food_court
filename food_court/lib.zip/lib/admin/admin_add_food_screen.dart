import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AdminAddFoodScreen extends StatefulWidget {
  @override
  _AdminAddFoodScreenState createState() => _AdminAddFoodScreenState();
}

class _AdminAddFoodScreenState extends State<AdminAddFoodScreen> {
  final _formKey = GlobalKey<FormState>();
  String? _selectedRestaurantId;
  String _title = '';
  String _slogan = '';
  double _price = 0.0;
  String _image = '';
  bool _isLoading = false;

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate() || _selectedRestaurantId == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Please fill all fields')));
      return;
    }
    _formKey.currentState!.save();

    setState(() {
      _isLoading = true;
    });

    try {
      await FirebaseFirestore.instance.collection('foods').add({
        'restaurantId': _selectedRestaurantId,
        'title': _title,
        'slogan': _slogan,
        'price': _price,
        'image': _image,
      });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Food added successfully')));
      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to add food')));
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Food'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: _isLoading
            ? Center(child: CircularProgressIndicator())
            : Form(
                key: _formKey,
                child: ListView(
                  children: [
                    StreamBuilder<QuerySnapshot>(
                      stream: FirebaseFirestore.instance.collection('restaurants').snapshots(),
                      builder: (context, snapshot) {
                        if (!snapshot.hasData) return CircularProgressIndicator();
                        final restaurants = snapshot.data!.docs;
                        return DropdownButtonFormField<String>(
                          decoration: InputDecoration(labelText: 'Select Restaurant'),
                          items: restaurants
                              .map((doc) => DropdownMenuItem<String>(
                                    value: doc.id,
                                    child: Text(doc['title']),
                                  ))
                              .toList(),
                          value: _selectedRestaurantId,
                          onChanged: (value) {
                            setState(() {
                              _selectedRestaurantId = value;
                            });
                          },
                          validator: (value) => value == null ? 'Please select a restaurant' : null,
                        );
                      },
                    ),
                    TextFormField(
                      decoration: InputDecoration(labelText: 'Title'),
                      validator: (value) => value == null || value.isEmpty ? 'Please enter title' : null,
                      onSaved: (value) => _title = value!.trim(),
                    ),
                    TextFormField(
                      decoration: InputDecoration(labelText: 'Slogan'),
                      validator: (value) => value == null || value.isEmpty ? 'Please enter slogan' : null,
                      onSaved: (value) => _slogan = value!.trim(),
                    ),
                    TextFormField(
                      decoration: InputDecoration(labelText: 'Price'),
                      keyboardType: TextInputType.numberWithOptions(decimal: true),
                      validator: (value) {
                        if (value == null || value.isEmpty) return 'Please enter price';
                        if (double.tryParse(value) == null) return 'Enter a valid number';
                        return null;
                      },
                      onSaved: (value) => _price = double.parse(value!),
                    ),
                    TextFormField(
                      decoration: InputDecoration(labelText: 'Image URL'),
                      validator: (value) => value == null || value.isEmpty ? 'Please enter image URL' : null,
                      onSaved: (value) => _image = value!.trim(),
                    ),
                    SizedBox(height: 20),
                    ElevatedButton(
                      onPressed: _submit,
                      child: Text('Add Food'),
                    ),
                  ],
                ),
              ),
      ),
    );
  }
}
